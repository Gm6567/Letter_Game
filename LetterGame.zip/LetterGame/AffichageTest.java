package fr.esiea.unique.MichelFinel.LetterGame;

import junit.framework.TestCase;

public class AffichageTest extends TestCase {

	// rien à tester ici , les fonctions présentes dans cette classe appelent d'autres fonctions mais ne retournent rien

}
