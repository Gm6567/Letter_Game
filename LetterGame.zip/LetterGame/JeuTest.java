package fr.esiea.unique.MichelFinel.LetterGame;

import junit.framework.TestCase;

public class JeuTest extends TestCase {

	public void testMenu() {
		// rien à tester ici
	}

}
